from keep2notion.keep import main

if __name__ == "__main__":
    main()
